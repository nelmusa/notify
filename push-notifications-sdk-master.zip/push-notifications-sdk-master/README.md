Pushwoosh Push Notifications SDK
================================

Push notifications SDK

SDK's are now separate subprojects on github. To clone them properly please use *--recursive* option:  
`git clone https://github.com/Pushwoosh/push-notifications-sdk.git --recursive`

Or run the following command after clone:  
`git submodule update --init`

###Contents

####SDK folder
Pushwoosh push notifications SDK for various platforms

####SDK Sample Projects
Ready-to-build sample projects for various platforms with Pushwoosh SDK integrated

Pushwoosh
http://www.pushwoosh.com